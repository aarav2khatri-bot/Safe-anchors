package dev.aarav.safeanchor;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Properties;
import java.util.function.IntConsumer;

/**
 * Client-side only. Every module is triggered by a key press and replays a fixed
 * sequence of inputs, one step every DELAY_TICKS ticks. No targeting, no reactions.
 *
 *  G  Safe Anchor    : place anchor, charge, glowstone shield, totem detonate
 *  J  Double Anchor  : two stacked anchors, charge both, shield, detonate both
 *  H  Double Hand    : totem in offhand + totem in mainhand
 *
 * Commands (client-side, never sent to the server), all take 1-9:
 *  /anchor  /glowstone  /totem  /totem2
 *  (/anchorslot and /glowslot also work)
 */
public class SafeAnchorClient implements ClientModInitializer {
    private static final int DELAY_TICKS = 2;

    private static int anchorSlot = 1, glowSlot = 2, totemSlot = 5, totem2Slot = 6;

    private static KeyBinding safeKey, doubleAnchorKey, doubleHandKey;

    private interface Act { boolean run(MinecraftClient mc, ClientPlayerEntity p); }

    private static final Deque<Act> queue = new ArrayDeque<>();
    private static int wait = 0;

    @Override
    public void onInitializeClient() {
        loadConfig();

        safeKey = reg("key.safeanchor.safe", GLFW.GLFW_KEY_G);
        doubleAnchorKey = reg("key.safeanchor.double_anchor", GLFW.GLFW_KEY_J);
        doubleHandKey = reg("key.safeanchor.double_hand", GLFW.GLFW_KEY_H);

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(slotCommand("anchor", "Anchor", v -> anchorSlot = v));
            dispatcher.register(slotCommand("anchorslot", "Anchor", v -> anchorSlot = v));
            dispatcher.register(slotCommand("glowstone", "Glowstone", v -> glowSlot = v));
            dispatcher.register(slotCommand("glowslot", "Glowstone", v -> glowSlot = v));
            dispatcher.register(slotCommand("totem", "Totem", v -> totemSlot = v));
            dispatcher.register(slotCommand("totem2", "Second totem", v -> totem2Slot = v));
        });
    }

    private static KeyBinding reg(String id, int key) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyBinding(id, InputUtil.Type.KEYSYM, key, "category.safeanchor"));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> slotCommand(
            String name, String label, IntConsumer setter) {
        return ClientCommandManager.literal(name)
                .then(ClientCommandManager.argument("slot", IntegerArgumentType.integer(1, 9))
                        .executes(ctx -> {
                            int v = IntegerArgumentType.getInteger(ctx, "slot");
                            setter.accept(v);
                            saveConfig();
                            ctx.getSource().sendFeedback(Text.literal(label + " slot set to " + v));
                            return 1;
                        }));
    }

    // ------------------------------------------------------------------ tick

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            queue.clear();
            return;
        }

        if (queue.isEmpty()) {
            boolean safe = drain(safeKey), dbl = drain(doubleAnchorKey), hands = drain(doubleHandKey);
            if (hands) queueDoubleHand(p);
            else if (safe || dbl) {
                BlockHitResult hit = aimed(mc);
                if (hit == null) p.sendMessage(Text.literal("Aim at a block first"), true);
                else if (safe) queueSafeAnchor(hit);
                else queueDoubleAnchor(hit);
            }
            return;
        }

        if (wait > 0) { wait--; return; }
        Act a = queue.poll();
        if (!a.run(mc, p)) queue.clear();
        else wait = DELAY_TICKS;
    }

    private static boolean drain(KeyBinding k) {
        boolean pressed = false;
        while (k.wasPressed()) pressed = true;
        return pressed;
    }

    private static BlockHitResult aimed(MinecraftClient mc) {
        return (mc.crosshairTarget instanceof BlockHitResult h && h.getType() == HitResult.Type.BLOCK) ? h : null;
    }

    // ------------------------------------------------------------- sequences

    private static void queueSafeAnchor(BlockHitResult hit) {
        BlockPos a = hit.getBlockPos().offset(hit.getSide());
        queue.add((mc, p) -> { select(p, anchorSlot); use(mc, p, hit); return true; });
        queue.add((mc, p) -> charge(mc, p, a));
        queue.add((mc, p) -> shield(mc, p, a, false));
        queue.add((mc, p) -> detonate(mc, p, a));
    }

    private static void queueDoubleAnchor(BlockHitResult hit) {
        BlockPos a = hit.getBlockPos().offset(hit.getSide());
        BlockPos b = a.up();
        queue.add((mc, p) -> { select(p, anchorSlot); use(mc, p, hit); return true; });
        queue.add((mc, p) -> charge(mc, p, a));
        queue.add((mc, p) -> { // second anchor on top of the first
            if (!anchorAt(mc, a)) return fail(p, "First anchor missing");
            select(p, anchorSlot);
            use(mc, p, faceHit(a, Direction.UP));
            return true;
        });
        queue.add((mc, p) -> charge(mc, p, b));
        queue.add((mc, p) -> shield(mc, p, a, false)); // ground-level shield
        queue.add((mc, p) -> shield(mc, p, a, true));  // upper shield
        queue.add((mc, p) -> detonate(mc, p, a));
        queue.add((mc, p) -> detonate(mc, p, b));
    }

    private static void queueDoubleHand(ClientPlayerEntity p) {
        if (totemSlot == totem2Slot) {
            p.sendMessage(Text.literal("Use /totem and /totem2 with different slots"), true);
            return;
        }
        queue.add((mc, pl) -> { select(pl, totemSlot); return true; });
        queue.add((mc, pl) -> {
            if (mc.getNetworkHandler() == null) return false;
            mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.SWAP_ITEMS_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
            return true;
        });
        queue.add((mc, pl) -> { select(pl, totem2Slot); return true; });
    }

    // ---------------------------------------------------------------- steps

    private static boolean charge(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        if (!anchorAt(mc, pos)) return fail(p, "Anchor wasn't placed");
        select(p, glowSlot);
        use(mc, p, faceHit(pos, dirToPlayer(p, pos)));
        return true;
    }

    /** Glowstone block between you and the anchor. upper=true stacks one more on top of it. */
    private static boolean shield(MinecraftClient mc, ClientPlayerEntity p, BlockPos anchor, boolean upper) {
        BlockPos s = anchor.offset(dirToPlayer(p, anchor));
        BlockPos base = upper ? s : s.down();
        select(p, glowSlot);
        use(mc, p, new BlockHitResult(Vec3d.ofCenter(base).add(0, 0.5, 0), Direction.UP, base, false));
        return true;
    }

    private static boolean detonate(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        if (!anchorAt(mc, pos)) return fail(p, "Anchor missing");
        select(p, totemSlot);
        use(mc, p, faceHit(pos, dirToPlayer(p, pos)));
        return true;
    }

    // -------------------------------------------------------------- helpers

    private static boolean anchorAt(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR);
    }

    private static Direction dirToPlayer(ClientPlayerEntity p, BlockPos pos) {
        Vec3d c = Vec3d.ofCenter(pos);
        return Direction.getFacing(p.getX() - c.x, 0, p.getZ() - c.z);
    }

    private static BlockHitResult faceHit(BlockPos pos, Direction side) {
        Vec3d c = Vec3d.ofCenter(pos).add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        return new BlockHitResult(c, side, pos, false);
    }

    private static void select(ClientPlayerEntity p, int slot1to9) {
        p.getInventory().selectedSlot = slot1to9 - 1;
    }

    private static void use(MinecraftClient mc, ClientPlayerEntity p, BlockHitResult hit) {
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
    }

    private static boolean fail(ClientPlayerEntity p, String msg) {
        p.sendMessage(Text.literal("Safe Anchor: " + msg), true);
        return false;
    }

    // ---- tiny config persistence ----
    private static Path cfgPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("safeanchor.properties");
    }

    private static void loadConfig() {
        Path p = cfgPath();
        if (!Files.exists(p)) return;
        try (InputStream in = Files.newInputStream(p)) {
            Properties props = new Properties();
            props.load(in);
            anchorSlot = clamp(props.getProperty("anchor"), anchorSlot);
            glowSlot = clamp(props.getProperty("glowstone"), glowSlot);
            totemSlot = clamp(props.getProperty("totem"), totemSlot);
            totem2Slot = clamp(props.getProperty("totem2"), totem2Slot);
        } catch (IOException ignored) { }
    }

    private static void saveConfig() {
        Properties props = new Properties();
        props.setProperty("anchor", String.valueOf(anchorSlot));
        props.setProperty("glowstone", String.valueOf(glowSlot));
        props.setProperty("totem", String.valueOf(totemSlot));
        props.setProperty("totem2", String.valueOf(totem2Slot));
        try (OutputStream out = Files.newOutputStream(cfgPath())) {
            props.store(out, "Safe Anchor hotbar slots (1-9)");
        } catch (IOException ignored) { }
    }

    private static int clamp(String s, int fallback) {
        try { int v = Integer.parseInt(s.trim()); return v >= 1 && v <= 9 ? v : fallback; }
        catch (Exception e) { return fallback; }
    }
}
