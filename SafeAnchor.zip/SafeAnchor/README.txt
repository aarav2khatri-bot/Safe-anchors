Safe Anchor (Fabric 1.21.1, client-side)

BUILD (needs JDK 21):
  Windows:  gradlew.bat build
  Mac/Linux: ./gradlew build
Output jar: build/libs/safeanchor-1.0.0.jar  (NOT the -sources jar)
Put it in .minecraft/mods along with Fabric Loader + Fabric API for 1.21.1.

KEYS (rebindable in Controls > Safe Anchor):
  G  Safe Anchor    - aim at a block: place, charge, glowstone shield, totem detonate
  J  Double Anchor  - aim at a block: two stacked anchors, both charged, shielded, both detonated
  H  Double Hand    - totem in offhand and mainhand

SLOT COMMANDS (client-side, saved to config), each takes 1-9:
  /anchor 1   /glowstone 2   /totem 5   /totem2 6
  (/anchorslot and /glowslot also work)
Defaults: anchor 1, glowstone 2, totem 5, second totem 6.
Double Hand needs totems in BOTH /totem and /totem2 slots (different slots).
